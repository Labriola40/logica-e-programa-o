﻿namespace AppLista03
{
    partial class FrmExercicio01
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl1 = new System.Windows.Forms.Label();
            this.txt1 = new System.Windows.Forms.TextBox();
            this.txt2 = new System.Windows.Forms.TextBox();
            this.lbl2 = new System.Windows.Forms.Label();
            this.txt3 = new System.Windows.Forms.TextBox();
            this.lbl3 = new System.Windows.Forms.Label();
            this.btn1 = new System.Windows.Forms.Button();
            this.btn3 = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.lblRSoma = new System.Windows.Forms.Label();
            this.lblRMedia = new System.Windows.Forms.Label();
            this.lblRPorcentagem = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Location = new System.Drawing.Point(94, 115);
            this.lbl1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(61, 24);
            this.lbl1.TabIndex = 0;
            this.lbl1.Text = "Num1";
            // 
            // txt1
            // 
            this.txt1.Location = new System.Drawing.Point(98, 145);
            this.txt1.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.txt1.Name = "txt1";
            this.txt1.Size = new System.Drawing.Size(138, 29);
            this.txt1.TabIndex = 1;
            this.txt1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txt2
            // 
            this.txt2.Location = new System.Drawing.Point(294, 145);
            this.txt2.Margin = new System.Windows.Forms.Padding(6);
            this.txt2.Name = "txt2";
            this.txt2.Size = new System.Drawing.Size(136, 29);
            this.txt2.TabIndex = 3;
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.Location = new System.Drawing.Point(290, 115);
            this.lbl2.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(61, 24);
            this.lbl2.TabIndex = 2;
            this.lbl2.Text = "Num2";
            this.lbl2.Click += new System.EventHandler(this.label2_Click);
            // 
            // txt3
            // 
            this.txt3.Location = new System.Drawing.Point(492, 145);
            this.txt3.Margin = new System.Windows.Forms.Padding(6);
            this.txt3.Name = "txt3";
            this.txt3.Size = new System.Drawing.Size(137, 29);
            this.txt3.TabIndex = 5;
            // 
            // lbl3
            // 
            this.lbl3.AutoSize = true;
            this.lbl3.Location = new System.Drawing.Point(488, 115);
            this.lbl3.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(61, 24);
            this.lbl3.TabIndex = 4;
            this.lbl3.Text = "Num3";
            // 
            // btn1
            // 
            this.btn1.Location = new System.Drawing.Point(152, 213);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(127, 39);
            this.btn1.TabIndex = 6;
            this.btn1.Text = "a) Soma";
            this.btn1.UseVisualStyleBackColor = true;
            this.btn1.Click += new System.EventHandler(this.btn1_Click);
            // 
            // btn3
            // 
            this.btn3.Location = new System.Drawing.Point(418, 213);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(192, 39);
            this.btn3.TabIndex = 7;
            this.btn3.Text = "c) Porcentagem";
            this.btn3.UseVisualStyleBackColor = true;
            this.btn3.Click += new System.EventHandler(this.btn3_Click);
            // 
            // btn2
            // 
            this.btn2.Location = new System.Drawing.Point(285, 213);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(127, 39);
            this.btn2.TabIndex = 8;
            this.btn2.Text = "b) Média";
            this.btn2.UseVisualStyleBackColor = true;
            this.btn2.Click += new System.EventHandler(this.btn2_Click);
            // 
            // lblRSoma
            // 
            this.lblRSoma.AutoSize = true;
            this.lblRSoma.Location = new System.Drawing.Point(290, 301);
            this.lblRSoma.Name = "lblRSoma";
            this.lblRSoma.Size = new System.Drawing.Size(148, 24);
            this.lblRSoma.TabIndex = 9;
            this.lblRSoma.Text = "Resultado Soma";
            this.lblRSoma.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblRMedia
            // 
            this.lblRMedia.AutoSize = true;
            this.lblRMedia.Location = new System.Drawing.Point(290, 339);
            this.lblRMedia.Name = "lblRMedia";
            this.lblRMedia.Size = new System.Drawing.Size(151, 24);
            this.lblRMedia.TabIndex = 10;
            this.lblRMedia.Text = "Resultado Média";
            // 
            // lblRPorcentagem
            // 
            this.lblRPorcentagem.AutoSize = true;
            this.lblRPorcentagem.Location = new System.Drawing.Point(290, 380);
            this.lblRPorcentagem.Name = "lblRPorcentagem";
            this.lblRPorcentagem.Size = new System.Drawing.Size(212, 24);
            this.lblRPorcentagem.TabIndex = 11;
            this.lblRPorcentagem.Text = "Resultado Porcentagem";
            // 
            // FrmExercicio01
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(741, 464);
            this.Controls.Add(this.lblRPorcentagem);
            this.Controls.Add(this.lblRMedia);
            this.Controls.Add(this.lblRSoma);
            this.Controls.Add(this.btn2);
            this.Controls.Add(this.btn3);
            this.Controls.Add(this.btn1);
            this.Controls.Add(this.txt3);
            this.Controls.Add(this.lbl3);
            this.Controls.Add(this.txt2);
            this.Controls.Add(this.lbl2);
            this.Controls.Add(this.txt1);
            this.Controls.Add(this.lbl1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.Name = "FrmExercicio01";
            this.Text = "frmExercicio01";
            this.Load += new System.EventHandler(this.FrmExercicio01_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.TextBox txt1;
        private System.Windows.Forms.TextBox txt2;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.TextBox txt3;
        private System.Windows.Forms.Label lbl3;
        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.Button btn3;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Label lblRSoma;
        private System.Windows.Forms.Label lblRMedia;
        private System.Windows.Forms.Label lblRPorcentagem;
    }
}

