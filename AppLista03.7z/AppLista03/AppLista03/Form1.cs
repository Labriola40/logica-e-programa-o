﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03
{
    public partial class FrmExercicio01 : Form
    {
        public FrmExercicio01()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void FrmExercicio01_Load(object sender, EventArgs e)
        {

        }

        private void btn1_Click(object sender, EventArgs e)
        {
            float num1 = float.Parse(txt1.Text);
            float num3 = float.Parse(txt3.Text);
            float soma;


            soma = num1 + num3;
            

            lblRSoma.Text = "Soma igual a " soma;



        }

        private void btn2_Click(object sender, EventArgs e)
        {
          float num1 = float.Parse(txt1.Text);
          float num2 = float.Parse(txt2.Text);
          float num3 = float.Parse (txt3.Text);
          float media;


            media = (num1 + num2 + num3) / 3;

            lblRMedia.Text = "Media igual a " + media;


        }

        private void btn3_Click(object sender, EventArgs e)
        {
            float num1 = float.Parse(txt1.Text);
            float num2 = float.Parse(txt2.Text);
            float num3 = float.Parse(txt3.Text);
            float total; porcNum1, porcNum2, porcNum3;

            total = num1 + num2 + num3;
            porcNum1 = num1 / total;
            porcNum2 = num2 / total;
            porcNum3 = num3 / total;
        }
    }
}
